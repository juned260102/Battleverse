BATTLEVERSE ANDROID PROJECT
===========================
This is a native Android Studio project for the Battleverse Raven Island prototype.

Build:
1. Install current Android Studio.
2. Open this folder as a project.
3. Let Gradle sync.
4. Run on an Android device/emulator.
5. For Play Store: Build > Generate Signed App Bundle / APK > Android App Bundle.

Current prototype:
- Native Android UI (not a browser)
- Command screen
- Raven Island map
- Alpha/Ronin loadout
- Matchmaking countdown
- Supplied concept art embedded as app resources

Important:
This is the foundation/prototype, not yet the full online 50-player game. Real multiplayer,
accounts, backend, anti-cheat, matchmaking servers, payments, analytics, live-ops, and
production game-engine combat still require implementation and infrastructure.