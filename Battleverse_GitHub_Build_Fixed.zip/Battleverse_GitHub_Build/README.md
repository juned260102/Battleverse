# Battleverse Android — GitHub Mobile Build

This project is prepared to build on GitHub Actions from a phone.

## Fix included
The Android/Kotlin JVM targets are explicitly set to Java/Kotlin 17 so the build does not fail with an inconsistent JVM target (Java 1.8 vs Kotlin 21).

## Build
Open **Actions → Battleverse Android Build → Run workflow**. The workflow builds a debug APK and a release AAB and uploads both as an artifact.

The release AAB is not signed for Play Store upload yet. A Play Store release needs a secure upload key/signing setup.
