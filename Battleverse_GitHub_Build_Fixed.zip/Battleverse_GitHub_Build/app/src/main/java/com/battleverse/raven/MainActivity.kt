package com.battleverse.raven

import android.graphics.Color
import android.os.Bundle
import android.os.CountDownTimer
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : android.app.Activity() {
    private val blue = Color.rgb(24,169,255)
    private val red = Color.rgb(255,49,69)
    private val bg = Color.rgb(3,7,13)
    private val panel = Color.rgb(8,17,28)
    private val line = Color.rgb(23,48,68)
    private val text = Color.rgb(233,244,255)
    private val muted = Color.rgb(127,148,167)
    private lateinit var content: LinearLayout
    private var timer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showHome()
    }

    private fun base(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 10, 12, 10)
            setBackgroundColor(bg)
        }
        val brand = tv("BATTLEVERSE", 19, text, true)
        brand.setPadding(6,0,0,0)
        top.addView(brand, LinearLayout.LayoutParams(0,56,1f))
        listOf("COMMAND","MAP","LOADOUT","MATCH").forEachIndexed { i, label ->
            val b = Button(this).apply {
                text = label
                textSize = 10f
                setTextColor(text)
                setOnClickListener { when(i){0->showHome();1->showMap();2->showLoadout();3->showMatch()} }
            }
            top.addView(b, LinearLayout.LayoutParams(0,56,1f))
        }
        root.addView(top)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 18)
        }
        val scroll = ScrollView(this).apply { addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        val foot = tv("BATTLEVERSE • RAVEN ISLAND • PROTOTYPE", 10, muted, false)
        foot.gravity = Gravity.CENTER
        root.addView(foot, LinearLayout.LayoutParams(-1,38))
        return root
    }

    private fun tv(s:String, size:Float, color:Int, bold:Boolean): TextView =
        TextView(this).apply {
            text=s; textSize=size; setTextColor(color)
            if(bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(16,16,16,16)
        background=GradientDrawable().apply { setColor(panel); setStroke(1,line); cornerRadius=18f }
    }

    private fun add(v:View, lp:LinearLayout.LayoutParams?=null) { content.addView(v, lp ?: LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,6,0,6)}) }

    private fun image(id:Int, h:Int): ImageView = ImageView(this).apply {
        setImageResource(id); scaleType=ImageView.ScaleType.CENTER_CROP
        layoutParams=LinearLayout.LayoutParams(-1,h).apply{setMargins(0,0,0,10)}
    }

    private fun action(label:String, click:()->Unit):Button = Button(this).apply {
        text=label; textSize=12f; setTextColor(text)
        background=GradientDrawable().apply{setColor(Color.rgb(7,18,28));setStroke(1,blue);cornerRadius=12f}
        setOnClickListener{click()}
    }

    private fun showHome(){
        timer?.cancel(); setContentView(base()); content.removeAllViews()
        val hero=card()
        hero.addView(image(com.battleverse.raven.R.drawable.vehicle_concept,260))
        hero.addView(tv("TWO LEGENDS • ONE WAR",11,blue,true))
        hero.addView(tv("RAVEN ISLAND",38,text,true))
        hero.addView(tv("Alpha vs Ronin. Explore the island, select your combat kit and prepare for the survival match.",15,muted,false))
        hero.addView(action("PLAY / FIND MATCH"){showMatch()})
        add(hero)
        val grid=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        grid.addView(stat("ALPHA","RAVEN UNIT",blue)); grid.addView(stat("RONIN","DIGITAL FRONTIER",red))
        grid.addView(stat("MATCH","50 PLAYERS • 15–20 MIN",blue)); grid.addView(stat("OBJECTIVE","SURVIVE",text))
        add(grid)
    }

    private fun stat(a:String,b:String,c:Int):View{
        val x=card(); x.addView(tv(a,11,muted,true)); x.addView(tv(b,22,c,true)); return x
    }

    private fun showMap(){
        timer?.cancel(); setContentView(base()); content.removeAllViews()
        val c=card(); c.addView(tv("RAVEN ISLAND",27,text,true)); c.addView(tv("Tactical survival map",13,muted,false))
        c.addView(image(R.drawable.map_concept,500)); c.addView(action("SHRINK SAFE ZONE"){ Toast.makeText(this,"Safe zone shrinking…",Toast.LENGTH_SHORT).show()})
        add(c)
        add(stat("HOT DROP","IRON FACTORY • NEON CITY",blue))
        add(stat("STEALTH","SHADOW FOREST • OLD VILLAGE",text))
        add(stat("HIGH RISK","FORTRESS",red))
    }

    private fun showLoadout(){
        timer?.cancel(); setContentView(base()); content.removeAllViews()
        add(tv("LOADOUT",28,text,true))
        listOf("◈  ENERGY DISC","⌁  DUAL PISTOLS","▣  HACKING DEVICE","╱  ENERGY BLADE").forEach{
            val c=card(); c.addView(tv(it,21,text,true)); c.addView(tv("FIELD EQUIPMENT",12,muted,false)); add(c)
        }
        val a=card(); a.addView(tv("ALPHA ABILITIES",18,blue,true))
        listOf("Raven Shield — DEFENSE","Tactical Scan — RECON","War Cry — BOOST","Claw Strike — MELEE").forEach{a.addView(tv(it,14,text,false))}
        add(a)
        val r=card(); r.addView(tv("RONIN ABILITIES",18,red,true))
        listOf("Light Dash — MOVE","Hack Pulse — HACK","Energy Disc — RANGED","Invisi-Step — STEALTH").forEach{r.addView(tv(it,14,text,false))}
        add(r)
    }

    private fun showMatch(){
        setContentView(base()); content.removeAllViews()
        val c=card(); c.gravity=Gravity.CENTER
        c.addView(tv("MATCHMAKING",12,blue,true), LinearLayout.LayoutParams(-1,50))
        val ring=tv("00:42",42,text,true); ring.gravity=Gravity.CENTER
        c.addView(ring,LinearLayout.LayoutParams(-1,180))
        c.addView(tv("SEARCHING FOR SURVIVORS",21,text,true))
        c.addView(tv("Raven Island • Squad queue",13,muted,false))
        val cancel=action("CANCEL SEARCH"){timer?.cancel();cancel.text="QUEUE CANCELLED"}
        c.addView(cancel)
        add(c)
        timer=object:CountDownTimer(42000,1000){
            var n=42
            override fun onTick(ms:Long){n--;ring.text="00:"+n.toString().padStart(2,'0')}
            override fun onFinish(){ring.text="00:00";cancel.text="SEARCH AGAIN"}
        }.start()
    }
}